// import "./Hoops.js";

let title;

let backgroundColor;
let mode;

let w, h;

let g1;

let buttonArray;
let gameElements;

let sbFont;
let standardFont;
let scoreNoise;
let missNoise;
let popSound;

let activeSongs;
let islandSound;

let doPreload = true;

let games;

var clicked = false;
var clacked = false;

const HOOPS_INDEX = 0;
const HOCKEY_INDEX = 1;
const BALLOONCUT_INDEX = 2;
const TIMETILES_INDEX = 3;

function preload() {
	if (doPreload) {
		sbFont = loadFont("./DSEG7Classic-Regular.ttf");
		standardFont = loadFont("standard.ttf");
		soundFormats('mp3');
		// backgroundMusic = loadSound('');
		scoreNoise = loadSound('sounds/score_noise.mp3');
		missNoise = loadSound('sounds/miss.mp3');
		popSound = loadSound('sounds/pop.mp3');
		islandSong = loadSound('sounds/island120bpm.mp3');
	}
}

function setup() {
	w = 500;
	h = 730;
	createCanvas(w, h);
	backgroundColor = color('white');


	initGameArray();

	buttonArray = [];
	gameElements = [];

	activeSongs = [];
	sp = new StatsPage();

	//initial mode -- "menu"
	menuMode();
}

function draw() {

	switch (mode) {
		case "menu":
			background(backgroundColor);
			drawTitle();
			break;
		case "games":
			background(backgroundColor);
			break;
		case "settings":
			background(backgroundColor);
			break;
		case "shop":
			background(backgroundColor);
            textAlign(CENTER);
            fill(50);
            textSize(35);
            text('Nothing available right now', w/2, h/2);
			break;
		case "stats":
			background(backgroundColor);
			sp.show();
			break;
		case "hoops":
			background(backgroundColor);
			runHoops();
			break;
		case "hockey":
			background(backgroundColor);
			runHockey();
			break;
		case "balloonCut":
			background(backgroundColor);
			runBalloonCut();
			break;
		case "timeTiles":
			fill('#d6ecef1D');
			rect(w / 2, h / 2, w, h)
			runTimeTiles();
			break;
		default:
		//  
	}

}

// Initialize the array of Games
function initGameArray() {
	games = [];
	for (var i = 0; i < 4; i++) {
		games.push(new Game());
	}

	games[HOOPS_INDEX].name = "Hoops";
	games[HOCKEY_INDEX].name = "Hockey";
	games[BALLOONCUT_INDEX].name = "Balloon Cut";
	games[TIMETILES_INDEX].name = "Time Tiles";
}


// Mode-transition Functions:
function menuMode() {
	backgroundColor = ('white');
	//create buttons
	initMenu();
	mode = "menu";
}

function gamesMode() {
	clearButtons();
	backgroundColor = ('lavenderblush');
	initGameButtons();

	mode = "games";
}

function settingsMode() {
	clearButtons();
	mode = "settings";

	backgroundColor = ('lightgray');
	let buttonWSize = 150;
	let buttonHSize = 100;

	buildButton("Mute Audio", (w / 2) - (buttonWSize), (h / 4 - buttonHSize / 2),
		buttonWSize * 2, buttonHSize, muteAudio);
	createBackButton1();
}

function shopMode() {
	clearButtons();
	backgroundColor = ('lemonchiffon');
	mode = "shop";

	createBackButton1();
}

function statsMode() {
	clearButtons();
	backgroundColor = ('beige');
	mode = "stats";

	createBackButton1();
}


//Page Objects
function StatsPage() {

	this.show = function () {

		textSize(20);
		fill('green');

		text('Average', 210, h / 5 - 50);
		text('Highscore', 340, h / 5 - 50);

		// Experimental
		for (var g = 0; g < games.length; g++) {
			textAlign(LEFT);
			text(games[g].name, 50, (h / 5) * (g + 1));
			textAlign(CENTER);
			text(str(games[g].avgScore), 210, h / 5 * (g + 1));
			text(str(games[g].highScore), 340, h / 5 * (g + 1));
		}
	}
}


// Action Functions
function muteAudio() {

}


// GUI Functions
function initMenu() {
	let buttonWSize = 150;
	let buttonHSize = 100;
	// Button Details
	buttonNames = ["Games", "Settings", "Shop", "Stats"];
	buttonPosX = [(w / 2) - (buttonWSize)];	// Same for all Menu Buttons
	// buttonPosY = [(h/8 + 20)-buttonHSize/2,buttonHSize/2 + 160,h/2-buttonHSize/2,h/1.5-buttonHSize/2];
	startY = (h / 5);
	vertOffset = h / 6;
	buttonSizeX = [buttonWSize * 2];	// Same for all Menu Buttons
	buttonSizeY = [buttonHSize];	// Same for all Menu Buttons
	buttonFunct = [gamesMode, settingsMode, shopMode, statsMode];

	// Loop through and create the buttons
	for (i = 0; i < buttonNames.length; i++) {
		buildButton(buttonNames[i], buttonPosX[0], startY + vertOffset * i,
			buttonSizeX[0], buttonSizeY[0], buttonFunct[i]);
	}
}

function initGameButtons() {
	let buttonWSize = 150;
	let buttonHSize = 100;

	gamePosX = (w / 2) - (buttonWSize);
	gameSizeX = buttonWSize * 2;

	// Button Details
	buttonNames = ["Hoops", "Hockey", "Balloon Cut", "Time Tiles"];
	buttonPosX = [gamePosX];		// All Game buttons are the same here
	startY = (h / 5);	// First button's Y location
	vertOffset = h / 6;				// Each button is spaced by this amount
	buttonSizeX = [gameSizeX];		// All Game buttons are the same here
	buttonSizeY = [buttonHSize];	// All Game buttons are the same here
	buttonFunct = [initHoops, initHockey, initBalloonCut, initTimeTiles];

	// Loop through and create the buttons
	for (i = 0; i < buttonNames.length; i++) {
		buildButton(buttonNames[i], buttonPosX[0], startY + vertOffset * i,
			buttonSizeX[0], buttonSizeY[0], buttonFunct[i]);
	}

	// Create back button
	createBackButton1();
}

function buildButton(name, posX, posY, sizeX, sizeY, funct) {
	theButton = createButton(name);
	theButton.position(posX, posY);
	theButton.style('font-size', '18px');
	theButton.size(sizeX, sizeY);
	theButton.mousePressed(funct);
	buttonArray.push(theButton);
}

// Back button to return to the main menu
function createBackButton1() {
	let buttonWSize = 80;
	let buttonHSize = 50;
	backButton1 = createButton('Back');
	backButton1.position(w / 12, w / 12);
	backButton1.size(buttonWSize, buttonHSize);
	backButton1.style('font-size', '18px');
	backButton1.mousePressed(backToMenu);
	buttonArray.push(backButton1);
}

// Back button to exit games
function createBackButton(w, h, label, x, y) {
	backButton = createButton(label);
	backButton.position(x, y);
	backButton.size(w, h);
	backButton.style('font-size', '18px');
	backButton.mousePressed(backToGames);
	buttonArray.push(backButton);
}

function clearButtons() {
	for (b = 0; b < buttonArray.length; b++) {
		buttonArray[b].remove();
	}
	buttonArray = [];
}

function drawTitle() {
	//print title
	textAlign(CENTER);
	fill(255, 0, 0);
	textSize(35);
	if (doPreload) {
		textFont(standardFont);
	}
	text('Game Station 359', (w / 2), h / 8);
}

function backToMenu() {
	clearButtons();
	menuMode();
}

function backToGames() {
	// Clear current game
	clearButtons();
	clearElements();
	//g1 = new EmptyGame()?  

	// End active songs
	for (i = 0; i < activeSongs.length; i++) {
		activeSongs[i].stop();
	}
	// Reset Mode
	gamesMode();

	// Resume looping
	frameCount = 0;
	loop();
}




// * * * * * * * G A M E S * * * * * * *//
// Game-initializing Functions
function initHoops() {
	clearButtons();
	mode = "hoops";
	createBackButton(80, 50, 'Back', w / 12, w / 12);
	drawScore(400, 20);

	games[HOOPS_INDEX].instance = new Hoops();
}
function initHockey() {
	clearButtons();
	mode = "hockey";
	createBackButton(80, 50, "Back", w / 12, w / 12);
	backgroundColor = (245);
	drawScore(400, 20);

	games[HOCKEY_INDEX].instance = new Hockey();
}
function initBalloonCut() {
	clearButtons();
	mode = "balloonCut";
	createBackButton(80, 50, "Back", w / 12, w / 12);
	backgroundColor = ('lightblue');
	drawScore(w * 0.85, 20);

	games[BALLOONCUT_INDEX].instance = new BalloonCut();
}
function initTimeTiles() {
	clearButtons();
	mode = "timeTiles";
	createBackButton(80, 50, "Back", w / 12, w / 12);
	backgroundColor = (214, 237, 239);
	drawScore(w * 0.85, 20);
    frameCount = 0;

	games[TIMETILES_INDEX].instance = new TimeTiles();
}


function Game() {
	this.instance = null;
	this.name = "";
	this.scores = [];
	this.avgScore = 0;
	this.highScore = 0;

	this.endGame = function (finalScore) {
		noLoop();
		this.scores.push(finalScore);
		this.avgScore = round(calcAvgScore(this.scores), 2);
		this.highScore = calcHighScore(this.scores);
	}
}




// HOOPS
// Game-running functions
function runHoops() {
	games[HOOPS_INDEX].instance.update();
	games[HOOPS_INDEX].instance.show();
}

// Game Instance Object
function Hoops() {
	// Status
	this.index = HOOPS_INDEX;
	this.name = games[this.index].name;
	this.live = true;

	// Scoring
	let scored = false;
	let currentScore = 0;
	this.previousScore = currentScore;

	// Objects
	let hoop = new Hoop();
	this.sb = new Scoreboard();
	this.balls = [];
	this.bouncingBalls = [];
	this.balls.push(new Ball(random(60, w - 60), mouseY, 50));

	// Other variables
	var gravity = 0.69;

	// MAIN FUNCTIONS
	// Updates all objects within the game
	this.update = function () {
		this.sb.update();
		for (b = 0; b < this.balls.length; b++) {
			this.balls[b].update();

			// Check if a basket has been made
			if (this.intersects(this.balls[b], hoop.scoreZone) && this.balls[b].yVel > 0) {
				if (!scored) {
					currentScore += 1;
					scored = true;

					if (doPreload) {
						scoreNoise.play();
					}

				}
			} else if (scored) {
				scored = false;
			}

			// Checks if ball is on ground
			if (this.balls[b].bounced) {
				// Add ball to bouncing array
				this.bouncingBalls.push(this.balls[b]);
				// Remove ball from the normal array
				this.balls.splice(this.balls.indexOf(this.balls[b]), 1);
				// Add next ball to shoot
				this.balls.push(new Ball(random(60, w - 60), mouseY, 50));
				// Check if ball score has not changed to give negative feedback
				if (this.previousScore == currentScore) {
					if (doPreload) {
						missNoise.play();
					}
				}
				this.previousScore = currentScore;
			}
		}

		try {  // Catch error till bouncingBalls is initialized
			for (b = this.bouncingBalls.length - 1; b > -1; b--) {
				this.bouncingBalls[b].update();
				if (this.bouncingBalls[b].x > w + 25 || this.bouncingBalls[b].x < 0 - 25 || this.bouncingBalls[b].bounces > 20) {
					this.bouncingBalls.splice(this.bouncingBalls.indexOf(this.bouncingBalls[b]), 1);
				}
			}
		} catch {

		}
	}

	// Displays all objects within the game
	this.show = function () {
		// floor
		fill(255, 180, 90);
		rectMode(CORNER);
		rect(0, w, h - 200, h);

		// hoop, scoreboard
		hoop.show();
		this.sb.show();
		scoreCounter.html('Score: ' + (currentScore));

		// balls
		for (b = this.bouncingBalls.length - 1; b > -1; b--) {
			this.bouncingBalls[b].show();
		}
		for (b = 0; b < this.balls.length; b++) {
			this.balls[b].show();
		}
	}



	// HOOPS GAME OBJECTS:
	function Hoop() {
		this.x = w / 2;
		this.y = h / 3;
		this.w = 160;
		this.h = 90;

		this.scoreZone = createVector(this.x, this.y + this.h);

		// For intersection
		this.boundX = (this.w / 2);
		this.boundY = (this.h);

		this.show = function () {
			stroke(0);
			fill(255);
			rectMode(CENTER);
			rect(this.x, this.y, this.w, this.h);
			noStroke();
			fill('red');
			rect(this.x, (this.y + 9), this.w * 0.75, this.h * 0.8);
			fill('white');
			rect(this.x, (this.y + 16), this.w * 0.6, this.h * 0.65);
			stroke('orange');
			strokeWeight(5);
			fill(0, 0);
			ellipse(this.x, this.y + this.h / 2 + 7, this.w * 0.6, this.h * 0.2)
			strokeWeight(1);
			noStroke();

		}
	}

	function Scoreboard() {
		this.x = w / 2;
		this.y = h / 9;
		this.w = 180;
		this.h = 90;
		this.timer = 60;

		this.update = function () {
			textSize(40);
			if (frameCount % 60 == 0 && this.timer > 0) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
				this.timer--;
			}
		}

		this.show = function () {
			fill(35);
			rectMode(CENTER);
			rect(this.x, this.y, this.w, this.h);

			fill(255, 0, 0);
			textAlign(CENTER, CENTER);
			if (doPreload) {
				textFont(sbFont);
			}
			text(this.timer, this.x, this.y);

			if (this.timer == 0) {
				text("GAME OVER", width / 2, height / 2);

				games[HOOPS_INDEX].endGame(currentScore);
			}
		}
	}

	function Ball(x, y, r) {
		this.x = x;
		this.y = h * 0.85;
		this.r = r;
		this.oldX = this.x;
		this.oldY = this.y;
		this.yVel = 0;
		this.xVel = 0;
		this.boundX = this.r;
		this.boundY = this.r;
		this.grabbed = false;
		this.released = false;
		this.bounced = false;
		this.bounces = 0;

		this.update = function () {
			if (this.grabbed) {
				if (!mouseIsPressed || this.y < hoop.scoreZone.y + 20) {
					this.calcVelocity();

					this.released = true;
					this.grabbed = false;
				}
				this.x = mouseX;
				this.y = mouseY;
			} else if (this.released) {
				// this.yVel = this.velocity().y;
				this.yVel += gravity;
				this.y += this.yVel;
				this.x -= this.xVel;

				if (this.y > h * 0.8) {
					this.y = h * 0.8 - 1;
					this.yVel *= -0.96;
					this.bounced = true;
					this.bounces += 1;
				}

			} else {
				// this.x = this.x;
				// this.y = this.y;
				if (mouseIsPressed && intersects(this.x, this.y, this.r / 2, mouseX, mouseY)) {
					this.grabbed = true;
				}
			}
		}

		this.show = function () {
			fill(250, 120, 30);
			stroke(0);
			ellipse(this.x, this.y, r, r);
			noStroke();
		}

		// Tracks position to calculate velocity
		this.calcVelocity = function () {
			this.oldX = this.x;
			this.oldY = this.y;
			this.xVel = (this.oldX - mouseX) * 0.69;
			this.yVel = -(this.oldY - mouseY) * 0.69;
		}
	}

	// HOOPS SUPPORTING FUNCTIONS
	// Method for checking the intersection of two objects
	this.intersects = function (obj1, obj2) {
		if (dist(obj1.x, obj1.y, obj2.x, obj2.y) < obj1.r) {
			return true;
		} else {
			return false;
		}
	}

}







// HOCKEY
// Game-running functions
function runHockey() {
	games[HOCKEY_INDEX].instance.update();
	games[HOCKEY_INDEX].instance.show();
}

function Hockey() {
	let oldX;
	let oldY;
	let currentScore = 0;
	this.sb = new Scoreboard();

	// Game Objects
	class Paddle {
		constructor(color) {
			this.x = 0;
			this.y = h * (2 / 3);
			this.r = 50;
			this.color = color;
			this.spring = 0.06;
		}

		display() {
			fill(this.color);
			stroke('black');
			strokeWeight(3);
			circle(this.x, this.y, 50);
			circle(this.x, this.y, 15);
		}

		updatePos() {
			if (mouseIsPressed) {
				this.x = mouseX;
				if (mouseY >= h / 2 + 18) {
					this.y = mouseY;
				} else {
					this.y = h / 2 + 18;
				}

				oldX = mouseX;
				oldY = mouseY;
			}
		}

		repel(other) {
			let minDist = other.r + this.r;
			var rise = (other.y - this.y);
			var run = (other.x - this.x);
			var angle = atan2(rise, run);
			var targetX = this.x + cos(angle) * minDist;
			var targetY = this.y + sin(angle) * minDist;
			var ax = (targetX - other.x) * this.spring;
			var ay = (targetY - other.y) * this.spring;
			other.velX += ax * 1.1;
			other.velY += ay * 1.1;
		}
	}

	class Puck {
		constructor(x, y) {
			this.x = x;
			this.y = y;
			this.r = 35;
			this.velX = 0;
			this.velY = 0;
			this.friction = 0.991;
		}

		display() {
			fill(225, 50, 50);
			stroke('black');
			strokeWeight(3);
			circle(this.x, this.y, 35);
		}

		move() {
			// Movement
			this.velX *= this.friction;
			this.velY *= this.friction;
			this.x += this.velX;
			this.y += this.velY;

			// Boundary checking
			if (this.x <= 0 + this.r)
				this.velX = abs(this.velX);
			if (this.x >= w - this.r)
				this.velX = -1 * abs(this.velX);
			if (this.y <= 0 + this.r)
				this.velY = abs(this.velY);
			if (this.y >= h - this.r)
				this.velY = -1 * abs(this.velY);

			// Reset puck
			if ((this.y < h / 2 - 30 && sqrt(pow(this.velX, 2) + pow(this.velY, 2)) < 0.15) || (key == 'r' && keyIsPressed)) {
				this.setPos(random(w / 2 - 175, w / 2 + 175), h / 2 + 40);
			}
		}

		setPos(x, y) {
			this.x = x;
			this.y = y;
			this.velX = 0;
			this.velY = 0;
		}
	}

	class ScoreZone {
		constructor() {
			this.x = w / 2;
			this.y = -30;
			this.r = 100;
		}

		display() {
			fill(0, 0, 0, 63);
			stroke('clear');
			strokeWeight(3);
			circle(this.x, this.y, 170);
		}
	}

	class Obstacle {
		constructor() {
			this.x = random(w / 2 + 90, w / 2 - 90);
			this.y = random(h / 4 - 130, h / 4);
			this.r = random(30, 60);
			this.spring = 0.06;
		}

		generate() {
			this.x = random(w / 2 + 90, w / 2 - 90);
			this.y = random(h / 4 - 130, h / 4);
			this.r = random(30, 60);
		}

		display() {
			fill(0, 0, 0);
			stroke('clear');
			strokeWeight(3);
			circle(this.x, this.y, this.r);
		}

		repel(other) {
			let minDist = other.r + this.r;
			var rise = (other.y - this.y);
			var run = (other.x - this.x);
			// this.yVelocity = this.yVelocity + other.yVelocity;
			// this.xVelocity = this.xVelocity + other.xVelocity;
			var angle = atan2(rise, run);
			var targetX = this.x + cos(angle) * minDist;
			var targetY = this.y + sin(angle) * minDist;
			var ax = (targetX - other.x) * this.spring;
			var ay = (targetY - other.y) * this.spring;
			other.velX += ax;
			other.velY += ay;
		}
	}


	// Initialize Hockey Objects
	let playerPaddle = new Paddle('blue');
	let puck1 = new Puck(w / 2, h / 2 + 50);
	let zone = new ScoreZone();
	let obstacle1 = new Obstacle();


	// Game-running functions
	this.update = function () {
		playerPaddle.updatePos();
		puck1.move();
		this.sb.update();

		// Detect Score
		if (this.intersects(zone, puck1)) {
			puck1.setPos(random(w / 2 - 175, w / 2 + 175), h / 2 + 40);
			obstacle1.generate();
			scoreNoise.play();
			currentScore += 1;
		}

		// Detect paddle/puck interaction
		if (mouseIsPressed && this.intersects(playerPaddle, puck1))
			playerPaddle.repel(puck1);

		// Detect obstacle/puck interaction
		if (this.intersects(puck1, obstacle1))
			obstacle1.repel(puck1);
	}

	this.show = function () {
		table();

		this.sb.show();
		zone.display();
		puck1.display();
		playerPaddle.display();
		obstacle1.display();

		noStroke();

		scoreCounter.html('Score: ' + (currentScore));
	}


	// Game-supporting functions
	function table() {
		stroke('white');
		fill(10, 200, 240);
		rect(0, h / 4, w, 5);
		rect(0, h - h / 4, w, 5);
		circle(w / 2, h / 2, 100);
		fill(245);
		circle(w / 2, h / 2, 90);
		fill(230, 100, 100);
		circle(w / 2, h / 2, 13);

		//top left red circle
		circle(w / 6, h / 4 - 90, 100);
		fill(245);
		circle(w / 6, h / 4 - 90, 90);
		fill(230, 100, 100);
		circle(w / 6, h / 4 - 90, 13);

		//top right red circle
		circle(w - w / 6, h / 4 - 90, 100);
		fill(245);
		circle(w - w / 6, h / 4 - 90, 90);
		fill(230, 100, 100);
		circle(w - w / 6, h / 4 - 90, 13);

		//bottom left red circle
		circle(w / 6, h - h / 4 + 90, 100);
		fill(245);
		circle(w / 6, h - h / 4 + 90, 90);
		fill(230, 100, 100);
		circle(w / 6, h - h / 4 + 90, 13);

		//bottom right red circle
		circle(w - w / 6, h - h / 4 + 90, 100);
		fill(245);
		circle(w - w / 6, h - h / 4 + 90, 90);
		fill(230, 100, 100);
		circle(w - w / 6, h - h / 4 + 90, 13);

		//goal circles
		fill(10, 200, 240);
		circle(w / 2, -20, 150);
		fill(245);
		circle(w / 2, -20, 140);
		fill(10, 200, 240);
		circle(w / 2, h + 20, 150);
		fill(245);
		circle(w / 2, h + 20, 140);

		//goals
		fill(100);
		rectMode('radius');
		rect(w / 2, 0, 72, 5);
		rect(w / 2, h, 72, 5);
	}

	this.intersects = function (obj1, obj2) {
		if (dist(obj1.x, obj1.y, obj2.x, obj2.y) < obj1.r) {
			return true;
		} else {
			return false;
		}
	}

	function Scoreboard() {
		this.x = w / 2;
		this.y = h / 2;
		this.w = 180;
		this.h = 90;
		this.timer = 60;

		this.update = function () {
			textSize(40);
			if (frameCount % 60 == 0 && this.timer > 0) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
				this.timer--;
			}
		}

		this.show = function () {
			if (doPreload) {
				textFont(sbFont);
			}
			textAlign(CENTER, CENTER);
			text(this.timer, this.x, this.y);
			if (this.timer == 0) {
				fill(100, 200)
				rect(this.x, this.y, width, this.h)
				fill(255, 0, 0);
				text("GAME OVER", width / 2, height / 2);
				games[HOCKEY_INDEX].endGame(currentScore);
			}
		}
	}
}



// BALLOON CUT
function runBalloonCut() {
	games[BALLOONCUT_INDEX].instance.update();
	games[BALLOONCUT_INDEX].instance.show();
}

function BalloonCut() {

	let balloons = [];
	let maxBalloons = 12;
	let spawnChance = 210;
	let currentScore = 0;
	let sparks = [];
	let rewards = [];

	this.sb = new Scoreboard();

	this.update = function () {
		this.sb.update();

		// Update balloons
		for (let b of balloons) {
			b.move();
			if (mouseIsPressed && b.swipe()) {
				rewards.push(new Reward(b.x, b.y));
				balloons.splice(balloons.indexOf(b), 1);
				popSound.play();
				currentScore += 1;
			}
		}

		// Generate new balloons based on total balloons and random chance
		if ((balloons.length < maxBalloons && (round(random(spawnChance)) == 1)) || (frameCount % 100 == 0)) {
			addBalloons(random(2));
		}

		// Update sparks
		for (let s of sparks) {
			s.update();
			if (s.age > 30)
				sparks.splice(sparks.indexOf(s), 1);
		}
		if (mouseIsPressed) {
			sparks.push(new Spark());
		}

		// Update rewards
		for (let r of rewards) {
			r.update();
			if (r.age > 40)
				rewards.splice(rewards.indexOf(r), 1);
		}
	}

	this.show = function () {
		this.sb.show();
		for (let b of balloons) {
			b.display();
		}

		for (let s of sparks) {
			s.show();
		}

		for (let r of rewards) {
			r.show();
		}

		scoreCounter.html('Score: ' + (currentScore));
	}


	function addBalloons(num) {
		// Add num balloons to the balloons array
		for (let count = 0; count < num; count++) {
			let tempBalloon = new Balloon(random(500, 510), color(random(255), random(255), random(255)));
			balloons.push(tempBalloon);
		}
	}

	// Balloon Cut Objects
	class Balloon {
		constructor(y, bcolor) {
			this.y = y;
			this.w = 75;//width of the balloon 
			this.l = 90;//length of the balloon
			this.bcolor = bcolor;
			this.swiped = false;
			this.xOff = random(10);
			this.x = noise(this.xOff) * width;
			this.yVel = random(1.2, 6);
		}

		move() {
			this.y -= this.yVel;
			this.xOff += 0.001;
			this.x = noise(this.xOff) * width;
		}

		display() {
			fill(this.bcolor);
			ellipse(this.x, this.y, this.w, this.l);
			stroke(0);
			line(this.x, this.y + this.l / 2, this.x, this.y + 123);
			noStroke();
		}

		// Return true if conditions are right to pop balloon
		swipe() {
			let distance = dist(this.x, this.y, mouseX, mouseY);
			if ((this.y < 200) && (distance <= this.w / 2) || ((distance <= this.l / 2))) {
				return true;
			}
			return false;
		}
	}

	class Reward {
		constructor(x, y) {
			this.x = x;
			this.y = y;
			this.age = 0;
		}

		update() {
			this.y -= 2;
			this.age += 1;
		}

		show() {
			textFont(standardFont);
			textSize(20);
			text("\+1", this.x, this.y);
		}
	}

	class Spark {
		constructor() {
			this.x = mouseX;
			this.y = mouseY;
			this.oldX = mouseX;
			this.oldY = mouseY;
			this.yVel = random(-2, 2);
			this.xVel = random(-2, 2);
			this.age = 0;
		}

		update() {
			this.oldX = this.x;
			this.oldY = this.y;
			this.x += this.xVel;
			this.y += 1 + this.yVel;
			this.age += 1;
		}

		show() {
			strokeWeight(3);
			stroke(255, 255, 50);
			line(this.oldX, this.oldY, this.x, this.y);
			noStroke();
		}
	}

	function Scoreboard() {
		this.x = w / 2;
		this.y = h / 9;
		this.w = 180;
		this.h = 90;
		this.timer = 30;

		this.update = function () {
			textSize(40);
			if (frameCount % 60 == 0 && this.timer > 0) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
				this.timer--;
			}
		}

		this.show = function () {
			fill(35);
			rectMode(CENTER);
			rect(this.x, this.y, this.w, this.h);

			fill(255, 0, 0);
			textAlign(CENTER, CENTER);
			if (doPreload) {
				textFont(sbFont);
			}
			text(this.timer, this.x, this.y);

			if (this.timer == 0) {
				text("GAME OVER", width / 2, height / 2);

				games[BALLOONCUT_INDEX].endGame(currentScore);
			}
		}
	}
}






// TIME TILES
// Game-running functions
function runTimeTiles() {
	games[TIMETILES_INDEX].instance.update();
	games[TIMETILES_INDEX].instance.show();
}

// Game Instance Object
function TimeTiles() {

	// Status
	this.index = TIMETILES_INDEX;
	this.name = games[this.index].name;
	this.live = true;
	let maxStatus = 6;
	let status = maxStatus;
	this.progressBar = new ProgressBar(islandSong);

	// Scoring
	let currentScore = 0;
	this.counter = 0;
	let streak = 0;

	// Objects
	this.aisles = [];
	let aisleCt = 5;

	// Other variables
	let tileRate = 2.69;
	let totalTiles = 0;
	let maxTiles = aisleCt * 3;
	let spawnChance = 250;
	let adjustedISDuration = 0.9186239680128976 * islandSong.duration();
	let reverb = new p5.Reverb();
	let aisleKeys = ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';'];

	// Create the aisles and set the keys
	for (var i = 0; i < aisleCt; i++) {
		var aw = w / aisleCt;
		this.aisles.push(new Aisle(((aw * (i + 1)) - (aw / 2)), aw));
		this.aisles[i].key = aisleKeys[i];
	}

	// Activate Music
	islandSong.play();
	activeSongs.push(islandSong);
	// islandSong.jump(70);
	islandSong.disconnect();
	reverb.process(islandSong, 3, 2);


	// MAIN FUNCTIONS
	// Update TimeTiles objects
	this.update = function () {
		// Update each aisle
		for (var i = 0; i < this.aisles.length; i++) {
			this.aisles[i].update();
		}

		// Update progress bar
		this.progressBar.update();

		// Adjust reverb based on how the player is doing
		dryWet = map(status, maxStatus, 0, 0, 1);
		reverb.drywet(dryWet);

		// End Game
		if (this.counter > 10) {
			if (this.progressBar.song.currentTime() < 0.01) {
				stroke(0);
				textSize(40);
				text("GAME OVER", width / 2, height / 2);
				games[TIMETILES_INDEX].endGame(currentScore);
			}
			this.counter = 0;
		}
		this.counter += 1;
	}

	// Show TimeTiles objects
	this.show = function () {

		for (var i = 0; i < this.aisles.length; i++) {
			this.aisles[i].show();
		}

		this.progressBar.show();

		scoreCounter.html('Score: ' + (currentScore));

		if (frameCount < 250) {
			for (var i = 0; i < this.aisles.length; i++) {
				let transparency = map(frameCount, 0, 250, 255, 0);
				fill(50, transparency);
				textFont(standardFont);
				textAlign(CENTER, CENTER);
				text("\'" + this.aisles[i].key + "\'", this.aisles[i].x, this.aisles[i].scoreZoneY);
			}
		}
	}


	// TIME TILES GAME OBJECTS:
	function Aisle(x, inW) {

		this.x = x;
		this.w = inW;
		this.h = h;

		this.key = '';

		this.scoreZoneY = h * (2 / 3);
		this.scoreZoneH = 75;

		this.hasGenerated = false;

		this.tiles = [];
		this.spawnY = -200;

		this.activated = false;
		this.fill = color(255, 255, 255, 255);
		this.aisleAlpha = 255;

		this.update = function () {

			// Update each tile and check for interaction
			for (var i = 0; i < this.tiles.length; i++) {
				this.tiles[i].update();

				if (this.tiles[i].evaluated == false) {
					if (((clicked && this.intersects()) || (clacked && (key === this.key))) && this.tiles[i].y > this.scoreZoneY - (this.tiles[i].h * 2)) {
						if (this.tiles[i].y > (this.scoreZoneY - this.scoreZoneH / 2) && this.tiles[i].y < (this.scoreZoneY + this.scoreZoneH / 2)) {  // On time
							streak++;
							if (streak < 5) {
								currentScore++;
							} else if (streak > 4 && streak < 10) {
								currentScore += 2;
							} else {
								currentScore += 3;
							}
							this.tiles[i].correct = true;
							this.fill = color(100, 255, 150);
							this.activated = true;
							if (status < maxStatus - 2.5) {
								status += 2.5;
							} else if (status < maxStatus) {
								status = maxStatus;
							}
							clacked = false;
						} else {  // Late
							streak = 0;
							this.tiles[i].correct = false;
							this.fill = color(255, 150, 100);
							this.activated = true;
							if (status > 0) {
								status--;
							}
							clacked = false;
						}
						this.tiles[i].evaluated = true;
					} else if (this.tiles[i].y > this.scoreZoneY + (this.tiles[i].h * 2.5)) {  // If tiles fall to low
						streak = 0;
						currentScore--;
						this.tiles[i].correct = false;
						this.tiles[i].evaluated = true;
						this.fill = color(255, 50, 50);
						this.activated = true;
						if (status > 0) {
							status -= 2;
						}
						clacked = false;
					}
				} else {
					if (this.tiles[i].y - this.tiles[i].h > h) {
						this.tiles.splice(i, 1);
						totalTiles--;
					}
				}
			}

			// Determine if there is enough room for a new tile
			let canGenerate = true;
			for (i = 0; i < this.tiles.length; i++) {
				if (this.tiles[i].y < (this.spawnY + this.tiles[i].h * 2 + this.scoreZoneH)) {
					canGenerate = false;
				}
			}
			// Generate new tiles based on total remaining tiles, proximity, and random chance
			if (totalTiles < maxTiles && (round(random(spawnChance)) == 1) && canGenerate) {
				this.tiles.push(new Tile(this.x, this.spawnY, this.w, 50));
			}

			// Flash if key pressed
			if (clacked && (key === this.key)) {
				this.fill = color(255, 255, 255);
				this.activated = true;
				clacked = false;
			}
		}

		this.show = function () {
			// The score zone
			noStroke();
			fill(255, 100, 100, 100);
			rectMode(CENTER);
			rect(this.x, this.scoreZoneY, this.w, 75);

			// Aisles highlighting
			stroke(0);
			if (this.activated) {
				this.aisleAlpha = 255;
				this.fill.setAlpha(this.aisleAlpha)
				this.activated = false;
			} else {
				this.aisleAlpha -= 80;
				this.fill.setAlpha(this.aisleAlpha);
			}
			this.fill.setAlpha(this.aisleAlpha);
			fill(this.fill)
			rect(this.x, h / 2, this.w, this.h);
			noStroke();

			// Show all aisle's tiles
			for (var i = 0; i < this.tiles.length; i++) {
				this.tiles[i].show();
			}
		}

		// Checks if the mouse is within the aisle
		this.intersects = function () {
			if (mouseX > this.x - this.w / 2 && mouseX < this.x + this.w / 2) {
				return true;
			}
			return false;
		}
		// Tile
		function Tile(x, y, inW, inH) {
			this.x = x;
			this.y = y;
			this.w = inW;
			this.h = 50;
			this.evaluated = false;
			this.correct = null;
			totalTiles++;

			this.update = function () {
				this.y += tileRate;
			}

			this.show = function () {
				if (this.correct == null) {
					fill(100, 150, 255, 50);
				} else if (this.correct == false) {
					fill(255, 150, 100, 50);
				} else {
					fill(100, 255, 150, 50);
				}
				rectMode(CENTER);
				rect(this.x, this.y, this.w, this.h);
			}

			function mousePressed() {
				if (mouseX < this.x + this.w && mouseX > this.x - this.w && mouseY < this.y + this.h / 2 && mouseY > this.y - this.h / 2) {
					return true;
				}
				return false;
			}
		}
	}

	// Progress Bar
	function ProgressBar(songIn) {
		this.songProgress = 0;
		this.song = songIn;
		let progressR = 30;
		let progressX = 0 + progressR;
		this.y = h - progressR * 2;


		this.update = function () {
			// progressR = ;
			progressX = map(this.song.currentTime() / adjustedISDuration, 0, 1, 0 + progressR, w - progressR);
			this.songProgress = this.song.currentTime() / adjustedISDuration;  //Use for adjusting difficulty or something.
		}

		this.show = function () {
			// The grey progress bar
			stroke(20);
			strokeWeight(2);
			fill(140, 140, 140, 100);
			rectMode(CENTER);
			rect(w / 2, this.y, w, progressR);
			strokeWeight(1);
			noStroke();
			// The bar showing space already covered
			fill(240, 0, 0, 200);
			rect(progressX / 2, this.y, progressX, progressR - 3)
			// The circle showing current spot in the song
			fill(240, 0, 0);  //consider adding feature: change color/size based on how well you're doing
			circle(progressX, this.y, progressR);
		}
	}
}





// Score
function drawScore(xpos, ypos) {
	scoreCounter = createDiv('Score: 0');
	scoreCounter.position(xpos, ypos);
	scoreCounter.id = 'score';
	scoreCounter.style('color', 'grey');
	gameElements.push(scoreCounter);
}


// ***** Functions that support all games ***** //
function clearElements() {
	for (e = 0; e < gameElements.length; e++) {
		gameElements[e].remove();
	}
	gameElements = [];
}

function calcAvgScore(scores) {
	let sum = 0;
	let average = 0;

	for (let i = 0; i < scores.length; i++) {
		sum += scores[i];
	}
	average = sum / scores.length;
	return average;
}

function calcHighScore(scores) {
	let max = 0;

	for (let i = 0; i < scores.length; i++) {
		if (scores[i] > max) {
			max = scores[i];
		}
	}
	return max;
}

function intersects(x1, y1, r1, x2, y2) {
	if (dist(x1, y1, x2, y2) < r1) {
		return true;
	} else {
		return false;
	}
}


// Interaction Functions
function mousePressed() {
	clicked = true;
}

function mouseReleased() {
	clicked = false;
}

function keyPressed() {
	// console.log(key)
	clacked = true;
}

function keyReleased() {
	clacked = false;
	key = '';
}
